package javaminiprjBankmgt;
import java.util.Scanner;
public class BankApplication {
	public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println(" *** WEL-COME TO ACCESS BANK  ACCOUNT DETAILS *** ");

        System.out.println(" Enter your 'Name':");
        System.out.println (" Enter your 'CustomerId':");
        String name=sc.nextLine();
        String customerId=sc.nextLine();
       //if()
        System.out.println("_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ __ _ ");
        System.out.println(" ");

        System.out.println(" ** REGISTRATION SUCCESSFULLY **....");
        System.out.println("_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ __ _ ");
        System.out.println(" ");

        BankAccount obj1=new BankAccount(name,customerId);
        obj1.menu();
    }
}
