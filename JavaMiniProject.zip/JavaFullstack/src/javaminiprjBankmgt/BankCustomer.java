package javaminiprjBankmgt;

public class BankCustomer {
   public String name;
   public String accountNumber;
   public String custNumber;
    //public double balance;

    // Constructor
    public BankCustomer(String name, String accountNumber, double initialBalance) 
    {
        this.name = name;
        this.accountNumber = accountNumber;
        this.custNumber=custNumber;
       // this.balance = initialBalance;
    }

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getCustNumber() {
		return custNumber;
	}

	public void setCustNumber(String custNumber) {
		this.custNumber = custNumber;
	}
}
    

   /* // Getter methods
    public String getName() {
        return name;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public double getBalance() {
        return balance;
    }*/